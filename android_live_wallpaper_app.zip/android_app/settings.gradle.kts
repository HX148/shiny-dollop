rootProject.name = "LiveWallpaper"
include(":app")
